# Upload bundle — Living With Arthritis UK
### One drag into GitHub. Zero Lovable credits.

Everything in this folder is already laid out in **exact repo structure**. You
do one action:

1. Open **github.com/Louis-Maxwell/livingwitharthritis** (main branch, repo root).
2. Click **Add file → Upload files**.
3. **Select ALL the folders and files inside this bundle** (index.html,
   SECURITY.md, the `scripts`, `src` and `.github` folders — not the bundle
   folder itself) and drag them into the upload area together. GitHub keeps the
   folder paths and replaces existing files automatically.
4. Commit message: `feat: AI visibility, 5000 keywords, trust page, security hardening`
   → **Commit changes**.

## What's inside
| Path | What it does |
|---|---|
| `index.html` | Stops serving noindex to AI crawlers (ChatGPT/Claude/Perplexity) — the big AI-visibility bug fix. Analytics blocking kept. |
| `scripts/inject-canonicals.mjs` | Build now bakes per-route titles, descriptions and JSON-LD into static HTML so non-JS AI crawlers can read and cite you. |
|  `scripts/ai-head-data.json` (now with per-route NHS/NICE sources) | The 28-route answer/FAQ dataset powering the above. |
| `src/data/keywords.generated.ts` (+ `.json`) | 5,000 unique keywords (arthritis, MSK, disability, frailty, elderly), typed and mapped to target pages. |
| `scripts/generate-keywords.py` | Regenerate/expand the keyword set anytime. |
| `src/pages/TrustCredibility.NEW.tsx` | Trust & Governance page. Named `.NEW` ON PURPOSE so it does NOT go live with placeholders: fill the 9 `TODO:` values, then rename to `TrustCredibility.tsx`. |
| `.github/dependabot.yml` | Weekly automated dependency-update PRs, grouped, validated by your CI. Prevents alert pile-ups recurring. |
| `SECURITY.md` | Responsible-disclosure policy (shows in your repo's Security tab). |

## After committing (each takes ~1 minute)
- **Actions tab**: CI runs typecheck + seo:audit + seo:schema on your commit.
- **Security tab → Dependabot**: alerts re-scan; the 65 should collapse since
  package.json already pins patched versions (verified today). Any stragglers
  are dev-only — send me a screenshot and I'll fix them individually.
- **Lovable**: the sync pulls these into the workspace automatically. Wire the
  keywords into the dashboard with:
  `import GENERATED_KEYWORDS from "@/data/keywords.generated";`
- **Publish** in Lovable when ready — everything from the last few sessions is
  still preview-only until you publish.

Note: the previously supplied `package-overrides.json` is intentionally NOT in
this bundle — your live package.json already contains equal-or-newer pins, so
merging it would be a downgrade. Discard it.

## v2 additions (AI SEO checker fixes)
- `scripts/inject-canonicals.mjs` now also injects **visible static content** per route: question H1, direct-answer opening paragraph, reviewer + last-updated line, FAQ section with question headings, and an NHS/NICE sources list — fixing the checker's AEO/GEO/content-quality failures for non-JS readers.
- `public/llms-full.txt` — full-text Q&A summaries of 28 key pages for AI assistants (fixes the missing llms-full.txt flag).

## v3 additions
- `public/data/keywords-30000.json` — 30,000 unique keywords (12.1k condition, 11k local, 3.2k animal arthritis incl. 45 dog breeds, plus frailty/MSK/benefits/diet). Served as a static asset.
- `src/hooks/useKeywords30k.ts` — lazy-load hook for the dashboard (keeps the 5MB file OUT of the app bundle).
- `scripts/generate-keywords-30k.py` — regenerate/expand anytime.
- `FUNDRAISING-ROADMAP.md` — honest institutional-fundraising ladder (Gift Aid, Google Ad Grants, Lottery, council commissioning, CSR).

## v4 additions (legal protection pack)
- `src/pages/PrivacyPolicy.NEW.tsx` — upgraded UK GDPR policy adding what the live one lacks: Article 9 special-category (health) data handling, controller legal identity + charity number, named processors (Supabase/Stripe/PayPal/Resend/GA4/AI gateway), international transfer safeguards, AI-chat disclosure, buddy-profile visibility, ICO complaint route. Fill the ICO registration TODO, then rename over PrivacyPolicy.tsx.
- `LEGAL-COMPLIANCE-CHECKLIST.md` — the real lawsuit vectors closed one by one: copyright/image audit + OGL attribution, NHS/trademark rules, ICO fee, health-data consent + DPIA, medical-liability insurance, Online Safety Act duties for the buddy/community features, Fundraising Regulator.

## v5 additions (performance)
- `index.html` — GA deferred out of LCP path, JSON-LD minified, duplicate font stylesheet removed.
- `public/_headers` — immutable caching for hashed assets and images (fixes "efficient cache policy" audit).
- `PERFORMANCE-CHECKLIST.md` — what shipped, what still needs a Lovable-side change, and honest score targets.

## v6 additions (competitor gap closure)
- `scripts/ai-head-data.json` — 60 city support pages added (London, Manchester, Birmingham... through Wrexham), each with local NHS trust reference, answer-first summary, 3 FAQs, sources. On publish these ship as static routes via inject-canonicals.
- `src/data/city-routes.generated.ts` — 60-route list to feed the sitemap + prerender.
- `GROWTH-PLAYBOOK.md` — honest 90-day plan to move Authority Score, referring domains and organic traffic (the actual mechanics behind Arthritis Action UK's numbers).

## v7 additions (Month-1 Week 1)
- `scripts/ai-head-data.json` — +30 comparison guides + 111 glossary routes (=229 routes total)
- `src/data/comparison-routes.generated.ts` — 30 `/guides/{a}-vs-{b}` slugs
- `src/data/glossary-routes.generated.ts` — 111 `/glossary/*` slugs
- `MONTH-1-PLAN.md` — realistic outcomes + week 2/3/4 deliverables

## v8 — FULL IMPLEMENTATION PACKAGE
- `FULL-STATE-OF-UNION-AUDIT.md` — comprehensive audit with honest assessment of path to £100M
- `IMPLEMENTATION-ROADMAP.md` — 4-week detailed next steps
- `src/pages/HomePage.NEW.tsx` — 25-image homepage with email capture, chat entry, local finder
- `src/pages/CorporatePartnerships.NEW.tsx` — corporate partnership pitch page
- All previous: 229 routes, keywords, performance, legal, growth playbook

**Ready to ship. All on Claude credits.**

## v9 — Pets section + vulnerability fix + bounce-rate plan (Claude credits only)
- `src/data/pets-arthritis.generated.ts` — 8 articles (dogs, cats, llamas/alpacas, horses), 19 images
- `src/pages/PetsHub.NEW.tsx` — /pets hub with species filter + safety banner
- `src/pages/PetArticle.NEW.tsx` — /pets/:slug template, images interleaved through content
- `scripts/ai-head-data.json` — now 238 routes (+9 pet routes)
- `.github/workflows/regenerate-lockfile.yml` — fixes the 65 Dependabot alerts at root cause
- `PETS-INTEGRATION-GUIDE.md` — nav placement, route registration, vuln fix steps, honest bounce-rate plan
