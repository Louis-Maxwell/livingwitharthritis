// AUTO-GENERATED — do not edit by hand. Regenerate with scripts/generate-keywords.py
// 5000 deduplicated UK keywords across arthritis, musculoskeletal,
// disability, frailty and elderly-care topics. Used by the Keyword Strategy
// dashboard (/admin/keyword-strategy) and to inform internal-linking + meta.
//
// Categories: {'condition': 1832, 'treatment': 643, 'exercise': 200, 'diet': 324, 'pain': 140, 'msk': 564, 'frailty': 56, 'elderly': 336, 'benefits': 234, 'caregiving': 66, 'local': 465, 'trust': 140}
// Intents:    {'informational': 3639, 'commercial': 892, 'local': 465, 'navigational': 4}

export type KeywordIntent =
  | "informational" | "commercial" | "transactional" | "navigational" | "local";

export interface KeywordRow {
  keyword: string;
  intent: KeywordIntent;
  category: string;
  cluster: string;
  targetPage: string;
}

export const GENERATED_KEYWORDS: KeywordRow[] = [
  {
    "keyword": "osteoarthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is osteoarthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can osteoarthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private osteoarthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for osteoarthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps osteoarthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make osteoarthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make osteoarthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce osteoarthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is osteoarthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does osteoarthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain osteoarthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "rheumatoid arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "early signs of rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what is rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to manage rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "living with rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is rheumatoid arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how serious is rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can rheumatoid arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best supplements for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best mattress for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best shoes for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best painkillers for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "private rheumatoid arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "heat pads for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "compression gloves for rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what helps rheumatoid arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what foods make rheumatoid arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can exercise make rheumatoid arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "should i rest or exercise with rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "when should i see a doctor about rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to sleep with rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to reduce rheumatoid arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is rheumatoid arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can i claim pip for rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "does rheumatoid arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what weather is best for rheumatoid arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to explain rheumatoid arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "psoriatic arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "early signs of psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "what is psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "how to manage psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "living with psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "is psoriatic arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "how serious is psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "can psoriatic arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "best supplements for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "best mattress for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "best shoes for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "best painkillers for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "private psoriatic arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "heat pads for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "compression gloves for psoriatic arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "what helps psoriatic arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "what foods make psoriatic arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "can exercise make psoriatic arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "should i rest or exercise with psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "when should i see a doctor about psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "how to sleep with psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "how to reduce psoriatic arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "is psoriatic arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "can i claim pip for psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "does psoriatic arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "what weather is best for psoriatic arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "how to explain psoriatic arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "gout symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "early signs of gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "what is gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "how to manage gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "living with gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "is gout hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "how serious is gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "can gout be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "best supplements for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "best mattress for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "best shoes for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "best painkillers for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "private gout treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "heat pads for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "compression gloves for gout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "what helps gout pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "what foods make gout worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "can exercise make gout worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "should i rest or exercise with gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "when should i see a doctor about gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "how to sleep with gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "how to reduce gout inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "is gout a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "can i claim pip for gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "does gout qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "what weather is best for gout",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "how to explain gout to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "ankylosing spondylitis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "early signs of ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "what is ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "how to manage ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "living with ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "is ankylosing spondylitis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "how serious is ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "can ankylosing spondylitis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "best supplements for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "best mattress for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "best shoes for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "best painkillers for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "private ankylosing spondylitis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "heat pads for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "compression gloves for ankylosing spondylitis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "what helps ankylosing spondylitis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "what foods make ankylosing spondylitis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "can exercise make ankylosing spondylitis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "should i rest or exercise with ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "when should i see a doctor about ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "how to sleep with ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "how to reduce ankylosing spondylitis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "is ankylosing spondylitis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "can i claim pip for ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "does ankylosing spondylitis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "what weather is best for ankylosing spondylitis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "how to explain ankylosing spondylitis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "fibromyalgia symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "early signs of fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "what is fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "how to manage fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "living with fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "is fibromyalgia hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "how serious is fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "can fibromyalgia be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "best supplements for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "best mattress for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "best shoes for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "best painkillers for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "private fibromyalgia treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "heat pads for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "compression gloves for fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "what helps fibromyalgia pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "what foods make fibromyalgia worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "can exercise make fibromyalgia worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "should i rest or exercise with fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "when should i see a doctor about fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "how to sleep with fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "how to reduce fibromyalgia inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "is fibromyalgia a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "can i claim pip for fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "does fibromyalgia qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "what weather is best for fibromyalgia",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "how to explain fibromyalgia to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "lupus symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "early signs of lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "what is lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "how to manage lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "living with lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "is lupus hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "how serious is lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "can lupus be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "best supplements for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "best mattress for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "best shoes for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "best painkillers for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "private lupus treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "heat pads for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "compression gloves for lupus",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "what helps lupus pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "what foods make lupus worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "can exercise make lupus worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "should i rest or exercise with lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "when should i see a doctor about lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "how to sleep with lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "how to reduce lupus inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "is lupus a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "can i claim pip for lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "does lupus qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "what weather is best for lupus",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "how to explain lupus to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "juvenile arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "early signs of juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "what is juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "how to manage juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "living with juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "is juvenile arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "how serious is juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "can juvenile arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "best supplements for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "best mattress for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "best shoes for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "best painkillers for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "private juvenile arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "heat pads for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "compression gloves for juvenile arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "what helps juvenile arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "what foods make juvenile arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "can exercise make juvenile arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "should i rest or exercise with juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "when should i see a doctor about juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "how to sleep with juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "how to reduce juvenile arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "is juvenile arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "can i claim pip for juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "does juvenile arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "what weather is best for juvenile arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "how to explain juvenile arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "reactive arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "early signs of reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "what is reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "how to manage reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "living with reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "is reactive arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "how serious is reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "can reactive arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "best supplements for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "best mattress for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "best shoes for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "best painkillers for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "private reactive arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "heat pads for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "compression gloves for reactive arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "what helps reactive arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "what foods make reactive arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "can exercise make reactive arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "should i rest or exercise with reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "when should i see a doctor about reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "how to sleep with reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "how to reduce reactive arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "is reactive arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "can i claim pip for reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "does reactive arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "what weather is best for reactive arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "how to explain reactive arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "polymyalgia rheumatica symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "early signs of polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "what is polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "how to manage polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "living with polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "is polymyalgia rheumatica hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "how serious is polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "can polymyalgia rheumatica be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "best supplements for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "best mattress for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "best shoes for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "best painkillers for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "private polymyalgia rheumatica treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "heat pads for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "compression gloves for polymyalgia rheumatica",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "what helps polymyalgia rheumatica pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "what foods make polymyalgia rheumatica worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "can exercise make polymyalgia rheumatica worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "should i rest or exercise with polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "when should i see a doctor about polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "how to sleep with polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "how to reduce polymyalgia rheumatica inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "is polymyalgia rheumatica a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "can i claim pip for polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "does polymyalgia rheumatica qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "what weather is best for polymyalgia rheumatica",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "how to explain polymyalgia rheumatica to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "knee arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "early signs of knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what is knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to manage knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "living with knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is knee arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how serious is knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can knee arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best supplements for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best mattress for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best shoes for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best painkillers for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "private knee arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "heat pads for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "compression gloves for knee arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what helps knee arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what foods make knee arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can exercise make knee arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "should i rest or exercise with knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "when should i see a doctor about knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to sleep with knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to reduce knee arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is knee arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can i claim pip for knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "does knee arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what weather is best for knee arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to explain knee arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "hip arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "early signs of hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "what is hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "how to manage hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "living with hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "is hip arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "how serious is hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "can hip arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "best supplements for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "best mattress for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "best shoes for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "best painkillers for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "private hip arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "heat pads for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "compression gloves for hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "what helps hip arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "what foods make hip arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "can exercise make hip arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "should i rest or exercise with hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "when should i see a doctor about hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "how to sleep with hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "how to reduce hip arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "is hip arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "can i claim pip for hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "does hip arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "what weather is best for hip arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "how to explain hip arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hand arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "early signs of hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what is hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to manage hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "living with hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is hand arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how serious is hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can hand arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best supplements for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best mattress for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best shoes for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best painkillers for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "private hand arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "heat pads for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "compression gloves for hand arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what helps hand arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what foods make hand arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can exercise make hand arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "should i rest or exercise with hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "when should i see a doctor about hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to sleep with hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to reduce hand arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is hand arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can i claim pip for hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "does hand arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what weather is best for hand arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to explain hand arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "shoulder arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "early signs of shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "what is shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "how to manage shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "living with shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "is shoulder arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "how serious is shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "can shoulder arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "best supplements for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "best mattress for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "best shoes for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "best painkillers for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "private shoulder arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "heat pads for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "compression gloves for shoulder arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "what helps shoulder arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "what foods make shoulder arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "can exercise make shoulder arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "should i rest or exercise with shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "when should i see a doctor about shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "how to sleep with shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "how to reduce shoulder arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "is shoulder arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "can i claim pip for shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "does shoulder arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "what weather is best for shoulder arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "how to explain shoulder arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "elbow arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "early signs of elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "what is elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "how to manage elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "living with elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "is elbow arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "how serious is elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "can elbow arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "best supplements for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "best mattress for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "best shoes for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "best painkillers for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "private elbow arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "heat pads for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "compression gloves for elbow arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "what helps elbow arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "what foods make elbow arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "can exercise make elbow arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "should i rest or exercise with elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "when should i see a doctor about elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "how to sleep with elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "how to reduce elbow arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "is elbow arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "can i claim pip for elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "does elbow arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "what weather is best for elbow arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "how to explain elbow arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "spinal arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is spinal arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can spinal arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private spinal arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for spinal arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps spinal arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make spinal arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make spinal arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce spinal arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is spinal arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does spinal arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for spinal arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain spinal arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "thumb arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "early signs of thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what is thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to manage thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "living with thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is thumb arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how serious is thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can thumb arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best supplements for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best mattress for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best shoes for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best painkillers for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "private thumb arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "heat pads for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "compression gloves for thumb arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what helps thumb arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what foods make thumb arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can exercise make thumb arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "should i rest or exercise with thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "when should i see a doctor about thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to sleep with thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to reduce thumb arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is thumb arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can i claim pip for thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "does thumb arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what weather is best for thumb arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to explain thumb arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "early signs of wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what is wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to manage wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "living with wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is wrist arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how serious is wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can wrist arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best supplements for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best mattress for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best shoes for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "best painkillers for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "private wrist arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "heat pads for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "compression gloves for wrist arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what helps wrist arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what foods make wrist arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can exercise make wrist arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "should i rest or exercise with wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "when should i see a doctor about wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to sleep with wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to reduce wrist arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "is wrist arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "can i claim pip for wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "does wrist arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "what weather is best for wrist arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "how to explain wrist arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "ankle arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "early signs of ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what is ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to manage ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "living with ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is ankle arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how serious is ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can ankle arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best supplements for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best mattress for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best shoes for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best painkillers for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "private ankle arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "heat pads for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "compression gloves for ankle arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what helps ankle arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what foods make ankle arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can exercise make ankle arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "should i rest or exercise with ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "when should i see a doctor about ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to sleep with ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to reduce ankle arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is ankle arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can i claim pip for ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "does ankle arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what weather is best for ankle arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to explain ankle arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "early signs of foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what is foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to manage foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "living with foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is foot arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how serious is foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can foot arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best supplements for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best mattress for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best shoes for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "best painkillers for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "private foot arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "heat pads for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "compression gloves for foot arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what helps foot arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what foods make foot arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can exercise make foot arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "should i rest or exercise with foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "when should i see a doctor about foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to sleep with foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to reduce foot arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "is foot arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "can i claim pip for foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "does foot arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "what weather is best for foot arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "how to explain foot arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "neck arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is neck arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can neck arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private neck arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for neck arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps neck arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make neck arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make neck arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce neck arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is neck arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does neck arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for neck arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain neck arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is facet joint arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can facet joint arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private facet joint arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for facet joint arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps facet joint arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make facet joint arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make facet joint arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce facet joint arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is facet joint arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does facet joint arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for facet joint arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain facet joint arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is cervical arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can cervical arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private cervical arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for cervical arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps cervical arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make cervical arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make cervical arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce cervical arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is cervical arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does cervical arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for cervical arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain cervical arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "inflammatory arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "early signs of inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what is inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to manage inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "living with inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is inflammatory arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how serious is inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can inflammatory arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best supplements for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best mattress for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best shoes for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best painkillers for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "private inflammatory arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "heat pads for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "compression gloves for inflammatory arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what helps inflammatory arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what foods make inflammatory arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can exercise make inflammatory arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "should i rest or exercise with inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "when should i see a doctor about inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to sleep with inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to reduce inflammatory arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is inflammatory arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can i claim pip for inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "does inflammatory arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what weather is best for inflammatory arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to explain inflammatory arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "degenerative arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early signs of degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what is degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to manage degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "living with degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is degenerative arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how serious is degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can degenerative arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best supplements for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best mattress for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best shoes for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "best painkillers for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "private degenerative arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "heat pads for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "compression gloves for degenerative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what helps degenerative arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what foods make degenerative arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can exercise make degenerative arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "should i rest or exercise with degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "when should i see a doctor about degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to sleep with degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to reduce degenerative arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "is degenerative arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "can i claim pip for degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "does degenerative arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "what weather is best for degenerative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to explain degenerative arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "seronegative arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "early signs of seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what is seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to manage seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "living with seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis flare up",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis in the morning",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis pain relief",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis exercises",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis diet",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis home remedies",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis stages",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis prognosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis vs osteoarthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is seronegative arthritis hereditary",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis and fatigue",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis nhs waiting times",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis nice guidelines",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis self management",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis explained",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis risk factors",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis complications",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis without medication",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis natural treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how serious is seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can seronegative arthritis be cured",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis life expectancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis support uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis blood test",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis x ray",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis physiotherapy",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis swelling",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis stiffness",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best supplements for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best mattress for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best shoes for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis braces",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis support gloves",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis gel",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis cream",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis tens machine",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis walking aids",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis ergonomic tools",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best painkillers for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis physiotherapist near me",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "private seronegative arthritis treatment cost uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis clinic uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis orthotics",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "heat pads for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "compression gloves for seronegative arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what helps seronegative arthritis pain at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what foods make seronegative arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can exercise make seronegative arthritis worse",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "should i rest or exercise with seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "when should i see a doctor about seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to sleep with seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to reduce seronegative arthritis inflammation",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "is seronegative arthritis a disability uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "can i claim pip for seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "does seronegative arthritis qualify for a blue badge",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "what weather is best for seronegative arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "how to explain seronegative arthritis to family",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "best exercises for knee arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle knee exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated knee exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "knee pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen knee with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe knee workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "knee exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for hip arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle hip exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated hip exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hip pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen hip with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe hip workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hip exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for hand arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle hand exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated hand exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "hand pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen hand with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe hand workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "hand exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for shoulder arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle shoulder exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated shoulder exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "shoulder pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen shoulder with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe shoulder workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "shoulder exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for elbow arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle elbow exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated elbow exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "elbow pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen elbow with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe elbow workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "elbow exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for wrist arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle wrist exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated wrist exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "wrist pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen wrist with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe wrist workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "wrist exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for thumb arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle thumb exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated thumb exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "thumb pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen thumb with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe thumb workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "thumb exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger arthritis exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for finger arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle finger exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated finger exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "finger pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen finger with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe finger workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "finger exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for ankle arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle ankle exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated ankle exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "ankle pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen ankle with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe ankle workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "ankle exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for foot arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle foot exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated foot exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "foot pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen foot with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe foot workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "foot exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for neck arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle neck exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated neck exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "neck pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen neck with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe neck workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "neck exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back arthritis exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for back arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle back exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated back exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "back pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen back with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe back workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "back exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine arthritis exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for spine arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle spine exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated spine exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "spine pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen spine with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe spine workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "spine exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe arthritis exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for toe arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle toe exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated toe exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "toe pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen toe with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe toe workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "toe exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw arthritis exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "best exercises for jaw arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw strengthening exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw stretches for arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw mobility exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "gentle jaw exercises for seniors",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw exercises to avoid with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "seated jaw exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw physiotherapy exercises",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw exercises at home",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw exercises for over 60s",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "jaw pain exercises nhs",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "how to strengthen jaw with arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "safe jaw workout arthritis",
    "intent": "informational",
    "category": "exercise",
    "cluster": "jaw exercise",
    "targetPage": "/exercise-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory diet for arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "mediterranean diet arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "foods to avoid with arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best foods for joint pain 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "turmeric for arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "omega 3 for arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "ginger for inflammation 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis diet plan uk 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory recipes uk 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "does sugar cause inflammation 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "dairy and arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "gluten and arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "weight loss for knee arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "supplements for joint health 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "glucosamine and chondroitin 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "collagen for joints 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "vitamin d and arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis breakfast ideas 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "anti inflammatory snacks 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis meal prep 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cod liver oil for joints 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "cherry juice for gout 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "purine foods to avoid gout 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis and alcohol 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "hydration and joint pain 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis friendly cooking 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis uk",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis nhs",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis evidence",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis reviews",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis that work",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis for beginners",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis for seniors",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis for elderly",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis plan",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis list",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "best oily fish for arthritis 7 day",
    "intent": "informational",
    "category": "diet",
    "cluster": "diet",
    "targetPage": "/diet-hub"
  },
  {
    "keyword": "arthritis pain relief at home",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain relief at home overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how to ease arthritis pain overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "natural arthritis pain relief overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up what to do overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up causes overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis flare up treatment overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "how long does an arthritis flare last overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "reduce joint inflammation fast overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat or ice for arthritis overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain at night overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis morning stiffness relief overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain in cold weather overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "topical pain relief arthritis overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens machine for arthritis overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "best painkiller for arthritis uk overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "codeine for arthritis overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "naproxen for arthritis overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis pain management plan overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "chronic joint pain help overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit uk",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit nhs",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit for elderly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit without medication",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit quickly",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "flare up survival kit overnight",
    "intent": "informational",
    "category": "pain",
    "cluster": "pain & flare",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "musculoskeletal health",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal health exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk conditions exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "musculoskeletal pain causes exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk physiotherapy exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back pain and arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint hypermobility exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tendonitis vs arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bursitis treatment exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sciatica exercises exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "lower back pain relief exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "muscle loss with age exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "sarcopenia treatment exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "how to build muscle after 60 exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "bone density exercises exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "osteoporosis and arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "improve grip strength elderly exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "balance exercises for seniors exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "posture and joint pain exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "msk waiting list nhs exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "first contact practitioner msk exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "physiotherapy self referral uk exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "joint protection techniques exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "occupational therapy arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hydrotherapy for joints exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "walking for joint health exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "swimming for arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "tai chi for arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "yoga for arthritis exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "pilates for joint pain exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors for elderly",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "resistance bands for seniors exercises",
    "intent": "informational",
    "category": "msk",
    "cluster": "musculoskeletal",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "frailty in elderly",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty in elderly free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent frailty free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "frailty assessment free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "clinical frailty scale free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "fall prevention for elderly free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "how to prevent falls at home free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "strength and balance classes free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "otago exercise programme free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "mobility aids for elderly free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall uk",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall nhs",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall guide",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall tips",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall at home",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall near me",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "getting up after a fall free",
    "intent": "informational",
    "category": "frailty",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly muscle weakness free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "staying active in old age free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "exercise for over 70s free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "chair exercises for seniors free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "gentle exercise for elderly free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "arthritis in old age free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly joint pain help free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "home adaptations for arthritis free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "grab rails for bathroom free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "walking frame vs rollator free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "care at home for arthritis free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "loneliness and chronic pain free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "keeping independent with arthritis free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "elderly nutrition for muscle free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "protein for older adults free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "vitamin d for over 65s free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "winter safety for elderly free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly guide",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly tips",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly at home",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly near me",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "cold weather joint pain elderly free",
    "intent": "informational",
    "category": "elderly",
    "cluster": "frailty & elderly",
    "targetPage": "/guides/frailty-management-hub"
  },
  {
    "keyword": "pip for arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip for arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to claim pip arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip points for arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip mobility arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "attendance allowance arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "universal credit arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge for arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "blue badge hidden disability checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disability benefits uk arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "adult disability payment scotland checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "access to work arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "esa for arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip assessment tips arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "pip appeal arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "is arthritis a disability uk checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "equality act arthritis workplace checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "reasonable adjustments arthritis work checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "council tax reduction disability checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "motability scheme arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "carers allowance uk checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "disabled facilities grant checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "vat relief disability aids checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "free prescriptions arthritis checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "bus pass disability uk checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "railcard disabled persons checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability 2026",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability uk",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability how much",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability eligibility",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability form help",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability calculator",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability explained",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "warm home discount disability checklist",
    "intent": "commercial",
    "category": "benefits",
    "cluster": "disability & benefits",
    "targetPage": "/guides/benefits-pip"
  },
  {
    "keyword": "how to help someone with arthritis",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "how to help someone with arthritis uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "how to help someone with arthritis nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "how to help someone with arthritis guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "how to help someone with arthritis advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "how to help someone with arthritis near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "caring for elderly parent with arthritis near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer support arthritis uk near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "helping a partner with chronic pain near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis carer tips near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "supporting someone newly diagnosed arthritis near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer burnout help uk near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "respite care arthritis near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "carer assessment uk near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "adaptations for a disabled relative near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain uk",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain nhs",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain guide",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain advice",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "communicating about chronic pain near me",
    "intent": "informational",
    "category": "caregiving",
    "cluster": "caregiving",
    "targetPage": "/guides/disability-support"
  },
  {
    "keyword": "arthritis support london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis physiotherapy london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis clinic london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "rheumatology london nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis exercise class london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "tai chi classes london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "hydrotherapy pool london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis support group london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "physiotherapy near me london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis help london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "arthritis support manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis physiotherapy manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis clinic manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "rheumatology manchester nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis exercise class manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "tai chi classes manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "hydrotherapy pool manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis support group manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "physiotherapy near me manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis help manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "arthritis support birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis physiotherapy birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis clinic birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "rheumatology birmingham nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis exercise class birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "tai chi classes birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "hydrotherapy pool birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis support group birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "physiotherapy near me birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis help birmingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:birmingham",
    "targetPage": "/arthritis-support/birmingham"
  },
  {
    "keyword": "arthritis support leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis physiotherapy leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis clinic leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "rheumatology leeds nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis exercise class leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "tai chi classes leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "hydrotherapy pool leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis support group leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "physiotherapy near me leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis help leeds",
    "intent": "local",
    "category": "local",
    "cluster": "local:leeds",
    "targetPage": "/arthritis-support/leeds"
  },
  {
    "keyword": "arthritis support glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis physiotherapy glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis clinic glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "rheumatology glasgow nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis exercise class glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "tai chi classes glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "hydrotherapy pool glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis support group glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "physiotherapy near me glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis help glasgow",
    "intent": "local",
    "category": "local",
    "cluster": "local:glasgow",
    "targetPage": "/arthritis-support/glasgow"
  },
  {
    "keyword": "arthritis support liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis physiotherapy liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis clinic liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "rheumatology liverpool nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis exercise class liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "tai chi classes liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "hydrotherapy pool liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis support group liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "physiotherapy near me liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis help liverpool",
    "intent": "local",
    "category": "local",
    "cluster": "local:liverpool",
    "targetPage": "/arthritis-support/liverpool"
  },
  {
    "keyword": "arthritis support bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis physiotherapy bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis clinic bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "rheumatology bristol nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis exercise class bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "tai chi classes bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "hydrotherapy pool bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis support group bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "physiotherapy near me bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis help bristol",
    "intent": "local",
    "category": "local",
    "cluster": "local:bristol",
    "targetPage": "/arthritis-support/bristol"
  },
  {
    "keyword": "arthritis support sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis physiotherapy sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis clinic sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "rheumatology sheffield nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis exercise class sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "tai chi classes sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "hydrotherapy pool sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis support group sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "physiotherapy near me sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis help sheffield",
    "intent": "local",
    "category": "local",
    "cluster": "local:sheffield",
    "targetPage": "/arthritis-support/sheffield"
  },
  {
    "keyword": "arthritis support edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis physiotherapy edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis clinic edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "rheumatology edinburgh nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis exercise class edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "tai chi classes edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "hydrotherapy pool edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis support group edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "physiotherapy near me edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis help edinburgh",
    "intent": "local",
    "category": "local",
    "cluster": "local:edinburgh",
    "targetPage": "/arthritis-support/edinburgh"
  },
  {
    "keyword": "arthritis support cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis physiotherapy cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis clinic cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "rheumatology cardiff nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis exercise class cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "tai chi classes cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "hydrotherapy pool cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis support group cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "physiotherapy near me cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis help cardiff",
    "intent": "local",
    "category": "local",
    "cluster": "local:cardiff",
    "targetPage": "/arthritis-support/cardiff"
  },
  {
    "keyword": "arthritis support newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis physiotherapy newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis clinic newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "rheumatology newcastle nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis exercise class newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "tai chi classes newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "hydrotherapy pool newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis support group newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "physiotherapy near me newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis help newcastle",
    "intent": "local",
    "category": "local",
    "cluster": "local:newcastle",
    "targetPage": "/arthritis-support/newcastle"
  },
  {
    "keyword": "arthritis support nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis physiotherapy nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis clinic nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "rheumatology nottingham nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis exercise class nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "tai chi classes nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "hydrotherapy pool nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis support group nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "physiotherapy near me nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis help nottingham",
    "intent": "local",
    "category": "local",
    "cluster": "local:nottingham",
    "targetPage": "/arthritis-support/nottingham"
  },
  {
    "keyword": "arthritis support belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis physiotherapy belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis clinic belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "rheumatology belfast nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis exercise class belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "tai chi classes belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "hydrotherapy pool belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis support group belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "physiotherapy near me belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis help belfast",
    "intent": "local",
    "category": "local",
    "cluster": "local:belfast",
    "targetPage": "/arthritis-support/belfast"
  },
  {
    "keyword": "arthritis support leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis physiotherapy leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis clinic leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "rheumatology leicester nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis exercise class leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "tai chi classes leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "hydrotherapy pool leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis support group leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "physiotherapy near me leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis help leicester",
    "intent": "local",
    "category": "local",
    "cluster": "local:leicester",
    "targetPage": "/arthritis-support/leicester"
  },
  {
    "keyword": "arthritis support southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis physiotherapy southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis clinic southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "rheumatology southampton nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis exercise class southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "tai chi classes southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "hydrotherapy pool southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis support group southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "physiotherapy near me southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis help southampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:southampton",
    "targetPage": "/arthritis-support/southampton"
  },
  {
    "keyword": "arthritis support portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis physiotherapy portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis clinic portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "rheumatology portsmouth nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis exercise class portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "tai chi classes portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "hydrotherapy pool portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis support group portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "physiotherapy near me portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis help portsmouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:portsmouth",
    "targetPage": "/arthritis-support/portsmouth"
  },
  {
    "keyword": "arthritis support brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis physiotherapy brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis clinic brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "rheumatology brighton nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis exercise class brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "tai chi classes brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "hydrotherapy pool brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis support group brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "physiotherapy near me brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis help brighton",
    "intent": "local",
    "category": "local",
    "cluster": "local:brighton",
    "targetPage": "/arthritis-support/brighton"
  },
  {
    "keyword": "arthritis support coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis physiotherapy coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis clinic coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "rheumatology coventry nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis exercise class coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "tai chi classes coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "hydrotherapy pool coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis support group coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "physiotherapy near me coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis help coventry",
    "intent": "local",
    "category": "local",
    "cluster": "local:coventry",
    "targetPage": "/arthritis-support/coventry"
  },
  {
    "keyword": "arthritis support hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis physiotherapy hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis clinic hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "rheumatology hull nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis exercise class hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "tai chi classes hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "hydrotherapy pool hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis support group hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "physiotherapy near me hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis help hull",
    "intent": "local",
    "category": "local",
    "cluster": "local:hull",
    "targetPage": "/arthritis-support/hull"
  },
  {
    "keyword": "arthritis support plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis physiotherapy plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis clinic plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "rheumatology plymouth nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis exercise class plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "tai chi classes plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "hydrotherapy pool plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis support group plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "physiotherapy near me plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis help plymouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:plymouth",
    "targetPage": "/arthritis-support/plymouth"
  },
  {
    "keyword": "arthritis support stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis physiotherapy stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis clinic stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "rheumatology stoke nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis exercise class stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "tai chi classes stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "hydrotherapy pool stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis support group stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "physiotherapy near me stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis help stoke",
    "intent": "local",
    "category": "local",
    "cluster": "local:stoke",
    "targetPage": "/arthritis-support/stoke"
  },
  {
    "keyword": "arthritis support wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis physiotherapy wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis clinic wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "rheumatology wolverhampton nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis exercise class wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "tai chi classes wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "hydrotherapy pool wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis support group wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "physiotherapy near me wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis help wolverhampton",
    "intent": "local",
    "category": "local",
    "cluster": "local:wolverhampton",
    "targetPage": "/arthritis-support/wolverhampton"
  },
  {
    "keyword": "arthritis support derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis physiotherapy derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis clinic derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "rheumatology derby nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis exercise class derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "tai chi classes derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "hydrotherapy pool derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis support group derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "physiotherapy near me derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis help derby",
    "intent": "local",
    "category": "local",
    "cluster": "local:derby",
    "targetPage": "/arthritis-support/derby"
  },
  {
    "keyword": "arthritis support swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis physiotherapy swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis clinic swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "rheumatology swansea nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis exercise class swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "tai chi classes swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "hydrotherapy pool swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis support group swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "physiotherapy near me swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis help swansea",
    "intent": "local",
    "category": "local",
    "cluster": "local:swansea",
    "targetPage": "/arthritis-support/swansea"
  },
  {
    "keyword": "arthritis support sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis physiotherapy sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis clinic sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "rheumatology sunderland nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis exercise class sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "tai chi classes sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "hydrotherapy pool sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis support group sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "physiotherapy near me sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis help sunderland",
    "intent": "local",
    "category": "local",
    "cluster": "local:sunderland",
    "targetPage": "/arthritis-support/sunderland"
  },
  {
    "keyword": "arthritis support oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis physiotherapy oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis clinic oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "rheumatology oxford nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis exercise class oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "tai chi classes oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "hydrotherapy pool oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis support group oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "physiotherapy near me oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis help oxford",
    "intent": "local",
    "category": "local",
    "cluster": "local:oxford",
    "targetPage": "/arthritis-support/oxford"
  },
  {
    "keyword": "arthritis support cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis physiotherapy cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis clinic cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "rheumatology cambridge nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis exercise class cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "tai chi classes cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "hydrotherapy pool cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis support group cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "physiotherapy near me cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis help cambridge",
    "intent": "local",
    "category": "local",
    "cluster": "local:cambridge",
    "targetPage": "/arthritis-support/cambridge"
  },
  {
    "keyword": "arthritis support york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis physiotherapy york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis clinic york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "rheumatology york nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis exercise class york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "tai chi classes york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "hydrotherapy pool york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis support group york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "physiotherapy near me york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis help york",
    "intent": "local",
    "category": "local",
    "cluster": "local:york",
    "targetPage": "/arthritis-support/york"
  },
  {
    "keyword": "arthritis support oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis physiotherapy oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis clinic oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "rheumatology oswestry nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis exercise class oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "tai chi classes oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "hydrotherapy pool oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis support group oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "physiotherapy near me oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis help oswestry",
    "intent": "local",
    "category": "local",
    "cluster": "local:oswestry",
    "targetPage": "/arthritis-support/oswestry"
  },
  {
    "keyword": "arthritis support shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis physiotherapy shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis clinic shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "rheumatology shrewsbury nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis exercise class shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "tai chi classes shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "hydrotherapy pool shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis support group shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "physiotherapy near me shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis help shrewsbury",
    "intent": "local",
    "category": "local",
    "cluster": "local:shrewsbury",
    "targetPage": "/arthritis-support/shrewsbury"
  },
  {
    "keyword": "arthritis support telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis physiotherapy telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis clinic telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "rheumatology telford nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis exercise class telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "tai chi classes telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "hydrotherapy pool telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis support group telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "physiotherapy near me telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis help telford",
    "intent": "local",
    "category": "local",
    "cluster": "local:telford",
    "targetPage": "/arthritis-support/telford"
  },
  {
    "keyword": "arthritis support chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis physiotherapy chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis clinic chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "rheumatology chester nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis exercise class chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "tai chi classes chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "hydrotherapy pool chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis support group chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "physiotherapy near me chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis help chester",
    "intent": "local",
    "category": "local",
    "cluster": "local:chester",
    "targetPage": "/arthritis-support/chester"
  },
  {
    "keyword": "arthritis support wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis physiotherapy wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis clinic wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "rheumatology wrexham nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis exercise class wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "tai chi classes wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "hydrotherapy pool wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis support group wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "physiotherapy near me wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis help wrexham",
    "intent": "local",
    "category": "local",
    "cluster": "local:wrexham",
    "targetPage": "/arthritis-support/wrexham"
  },
  {
    "keyword": "arthritis support reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis physiotherapy reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis clinic reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "rheumatology reading nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis exercise class reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "tai chi classes reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "hydrotherapy pool reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis support group reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "physiotherapy near me reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis help reading",
    "intent": "local",
    "category": "local",
    "cluster": "local:reading",
    "targetPage": "/arthritis-support/reading"
  },
  {
    "keyword": "arthritis support milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis physiotherapy milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis clinic milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "rheumatology milton keynes nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis exercise class milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "tai chi classes milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "hydrotherapy pool milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis support group milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "physiotherapy near me milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis help milton keynes",
    "intent": "local",
    "category": "local",
    "cluster": "local:milton keynes",
    "targetPage": "/arthritis-support/milton-keynes"
  },
  {
    "keyword": "arthritis support aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis physiotherapy aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis clinic aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "rheumatology aberdeen nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis exercise class aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "tai chi classes aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "hydrotherapy pool aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis support group aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "physiotherapy near me aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis help aberdeen",
    "intent": "local",
    "category": "local",
    "cluster": "local:aberdeen",
    "targetPage": "/arthritis-support/aberdeen"
  },
  {
    "keyword": "arthritis support dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis physiotherapy dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis clinic dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "rheumatology dundee nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis exercise class dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "tai chi classes dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "hydrotherapy pool dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis support group dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "physiotherapy near me dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis help dundee",
    "intent": "local",
    "category": "local",
    "cluster": "local:dundee",
    "targetPage": "/arthritis-support/dundee"
  },
  {
    "keyword": "arthritis support norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis physiotherapy norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis clinic norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "rheumatology norwich nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis exercise class norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "tai chi classes norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "hydrotherapy pool norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis support group norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "physiotherapy near me norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis help norwich",
    "intent": "local",
    "category": "local",
    "cluster": "local:norwich",
    "targetPage": "/arthritis-support/norwich"
  },
  {
    "keyword": "arthritis support exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis physiotherapy exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis clinic exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "rheumatology exeter nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis exercise class exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "tai chi classes exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "hydrotherapy pool exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis support group exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "physiotherapy near me exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis help exeter",
    "intent": "local",
    "category": "local",
    "cluster": "local:exeter",
    "targetPage": "/arthritis-support/exeter"
  },
  {
    "keyword": "arthritis support bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "arthritis physiotherapy bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "arthritis clinic bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "rheumatology bournemouth nhs",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "arthritis exercise class bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "tai chi classes bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "hydrotherapy pool bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "arthritis support group bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "physiotherapy near me bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "arthritis help bournemouth",
    "intent": "local",
    "category": "local",
    "cluster": "local:bournemouth",
    "targetPage": "/arthritis-support/bournemouth"
  },
  {
    "keyword": "living with arthritis charity",
    "intent": "navigational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "living with arthritis uk",
    "intent": "navigational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "is living with arthritis a real charity",
    "intent": "navigational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "living with arthritis charity number",
    "intent": "navigational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "free arthritis physiotherapy uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "arthritis charity donation uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "gift aid arthritis donation",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "arthritis charity gift aid",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "trusted arthritis information uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "medically reviewed arthritis advice",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "arthritis charity vs versus arthritis",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "best arthritis websites uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "arthritis foundation uk equivalent",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "nhs approved arthritis exercises",
    "intent": "informational",
    "category": "trust",
    "cluster": "trust & brand",
    "targetPage": "/trust-credibility"
  },
  {
    "keyword": "what is dmard",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "dmard meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "dmard explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is biologic drugs",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "biologic drugs meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "biologic drugs explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is nsaid",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "nsaid meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "nsaid explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is corticosteroid injection",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "corticosteroid injection meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "corticosteroid injection explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is synovium",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "synovium meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "synovium explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is cartilage",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "cartilage meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "cartilage explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is hla-b27",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "hla-b27 meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "hla-b27 explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is rheumatoid factor",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "rheumatoid factor meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "rheumatoid factor explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is anti-ccp",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "anti-ccp meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "anti-ccp explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is esr blood test",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "esr blood test meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "esr blood test explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is crp inflammation",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "crp inflammation meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "crp inflammation explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is joint effusion",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "joint effusion meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "joint effusion explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is crepitus",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "crepitus meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "crepitus explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is flare up",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "flare up meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "flare up explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is remission arthritis",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "remission arthritis meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "remission arthritis explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is seronegative",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "seronegative meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "seronegative explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is enthesitis",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "enthesitis meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "enthesitis explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is dactylitis",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "dactylitis meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "dactylitis explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is morning stiffness",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "morning stiffness meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "morning stiffness explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is bone spurs",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "bone spurs meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "bone spurs explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is osteophytes",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "osteophytes meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "osteophytes explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is subchondral",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "subchondral meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "subchondral explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is pannus",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "pannus meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "pannus explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is ankylosis",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "ankylosis meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "ankylosis explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is uric acid",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "uric acid meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "uric acid explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is tophi",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "tophi meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "tophi explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is physiotherapy triage",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "physiotherapy triage meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "physiotherapy triage explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is musculoskeletal",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "musculoskeletal meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "musculoskeletal explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is proprioception",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "proprioception meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "proprioception explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "what is range of motion",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "range of motion meaning",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "range of motion explained",
    "intent": "informational",
    "category": "treatment",
    "cluster": "glossary",
    "targetPage": "/glossary"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "paracetamol vs ibuprofen for arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "glucosamine vs turmeric reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "heat vs cold for joints reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "swimming vs walking for arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "yoga vs pilates for arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "knee replacement vs injections reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "physiotherapy vs surgery arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "nhs vs private rheumatology reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tens vs heat therapy reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "walking stick vs crutch reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "rollator vs walking frame reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "steroid injection vs hyaluronic acid reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "biologics vs dmards reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "osteoarthritis vs rheumatoid arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "arthritis vs fibromyalgia reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "gout vs pseudogout reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "bursitis vs arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tendonitis vs arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tendonitis vs arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "tendonitis vs arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis uk",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis which is better",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis for seniors",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis nhs",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "sciatica vs hip arthritis reviews",
    "intent": "commercial",
    "category": "treatment",
    "cluster": "comparisons",
    "targetPage": "/guides/arthritis-pain-relief"
  },
  {
    "keyword": "just diagnosed with arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "just diagnosed with arthritis support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis first 30 days support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "what to do after arthritis diagnosis support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "questions to ask rheumatologist support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis newly diagnosed guide support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "coming to terms with arthritis support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis and mental health support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "depression and chronic pain uk support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "arthritis fatigue management support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "working with arthritis support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "telling my employer about arthritis support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk advice",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk help",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk checklist",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "driving with arthritis uk support",
    "intent": "informational",
    "category": "condition",
    "cluster": "newly diagnosed",
    "targetPage": "/guides/newly-diagnosed"
  },
  {
    "keyword": "how to open jars with arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to open jars with arthritis cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "dressing aids for arthritis cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "kitchen gadgets for arthritis cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best pillow for neck arthritis cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "how to garden with arthritis cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly exercise dvd cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "typing with arthritis cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "driving aids for arthritis hands cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis and sleep problems cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "best chair for arthritis sufferers cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "getting out of bed with arthritis cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis stair aids cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "shoes for swollen arthritic feet cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis gloves for typing cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "jar openers for weak hands cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "button hooks for arthritis cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis friendly phone cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands reviews",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands amazon uk",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands best",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands nhs",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "voice control for disabled hands cheap",
    "intent": "informational",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "raised toilet seat arthritis cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "long handled shoe horn cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "easy grip cutlery elderly cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes womens cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis walking shoes mens cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis reviews",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis amazon uk",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis best",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis nhs",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "electric can opener arthritis cheap",
    "intent": "commercial",
    "category": "elderly",
    "cluster": "daily living",
    "targetPage": "/health-tools"
  },
  {
    "keyword": "arthritis in women",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in women nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "menopause and joint pain nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after pregnancy nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 30s nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in your 40s nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "early onset arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in men nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis and testosterone nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hand arthritis in women nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "hormones and joint pain nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis after 50 nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults symptoms",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults treatment",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults causes",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults help",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "arthritis in young adults nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "demographics",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "how to prevent arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "how to prevent arthritis for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "reduce arthritis risk for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "joint health tips for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "protect your knees for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "exercise to prevent joint pain for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "healthy joints diet for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "smoking and arthritis for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "obesity and osteoarthritis for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "occupation and arthritis risk for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "genetics and arthritis risk for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "stay mobile as you age for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 naturally",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 tips",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "keep joints healthy over 50 for life",
    "intent": "informational",
    "category": "msk",
    "cluster": "prevention",
    "targetPage": "/guides/preventative-msk-health"
  },
  {
    "keyword": "osteoarthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "osteoarthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "osteoarthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "rheumatoid arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "rheumatoid arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "psoriatic arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "psoriatic arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "psoriatic arthritis",
    "targetPage": "/conditions/psoriatic-arthritis"
  },
  {
    "keyword": "gout nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout video",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "gout physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "gout",
    "targetPage": "/conditions/gout"
  },
  {
    "keyword": "ankylosing spondylitis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "ankylosing spondylitis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankylosing spondylitis",
    "targetPage": "/conditions/ankylosing-spondylitis"
  },
  {
    "keyword": "fibromyalgia nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia video",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "fibromyalgia physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "fibromyalgia",
    "targetPage": "/conditions/fibromyalgia"
  },
  {
    "keyword": "lupus nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus video",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "lupus physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "lupus",
    "targetPage": "/conditions/lupus"
  },
  {
    "keyword": "juvenile arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "juvenile arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "juvenile arthritis",
    "targetPage": "/conditions/juvenile-arthritis"
  },
  {
    "keyword": "reactive arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "reactive arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "reactive arthritis",
    "targetPage": "/conditions/reactive-arthritis"
  },
  {
    "keyword": "polymyalgia rheumatica nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica video",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "polymyalgia rheumatica physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "polymyalgia rheumatica",
    "targetPage": "/conditions/polymyalgia-rheumatica"
  },
  {
    "keyword": "knee arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "knee arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "knee arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "hip arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hip arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "hip arthritis",
    "targetPage": "/conditions/hip-arthritis"
  },
  {
    "keyword": "hand arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "hand arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "hand arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "shoulder arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "shoulder arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "shoulder arthritis",
    "targetPage": "/conditions/shoulder-arthritis"
  },
  {
    "keyword": "elbow arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "elbow arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "elbow arthritis",
    "targetPage": "/conditions/elbow-arthritis"
  },
  {
    "keyword": "spinal arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "spinal arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "spinal arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "thumb arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "thumb arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "thumb arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "wrist arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "wrist arthritis",
    "targetPage": "/conditions/hand-arthritis"
  },
  {
    "keyword": "ankle arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "ankle arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "ankle arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "foot arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "foot arthritis",
    "targetPage": "/conditions/knee-arthritis"
  },
  {
    "keyword": "neck arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "neck arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "neck arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "facet joint arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "facet joint arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "cervical arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "cervical arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "inflammatory arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "inflammatory arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "inflammatory arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "degenerative arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "degenerative arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "degenerative arthritis",
    "targetPage": "/conditions/osteoarthritis"
  },
  {
    "keyword": "seronegative arthritis nhs",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis at home",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis for seniors",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis for over 60s",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis for over 70s",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis without surgery",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis exercises pdf",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis free guide",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis support near me",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis reddit uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis forum uk",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis self help",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis video",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis nice guideline",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "seronegative arthritis physiotherapy plan",
    "intent": "informational",
    "category": "condition",
    "cluster": "seronegative arthritis",
    "targetPage": "/conditions/rheumatoid-arthritis"
  },
  {
    "keyword": "knee joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "knee joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hip joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "hand joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "shoulder joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "elbow joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "wrist joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "thumb joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "finger joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "ankle joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "foot joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "neck joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "back joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "spine joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "toe joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain nhs",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain at home",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain for seniors",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain for over 60s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain for over 70s",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain without surgery",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain exercises pdf",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain free guide",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain support near me",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain reddit uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain forum uk",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain self help",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain video",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain nice guideline",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "jaw joint pain physiotherapy plan",
    "intent": "informational",
    "category": "msk",
    "cluster": "joint pain",
    "targetPage": "/guides/musculoskeletal-health"
  },
  {
    "keyword": "arthritis statistics uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis statistics uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "how many people have arthritis uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis prevalence uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "cost of arthritis to nhs explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis research uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "new arthritis treatments 2026 explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis awareness week uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "world arthritis day explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis and work statistics uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "osteoarthritis statistics explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatoid arthritis statistics uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "gout prevalence uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis waiting times nhs explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "rheumatology waiting list uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis in the workplace uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "economic impact of arthritis explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis disability statistics uk explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats 2026",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats latest",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats report",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats data",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats nhs",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "musculoskeletal conditions uk stats explained",
    "intent": "informational",
    "category": "trust",
    "cluster": "research & stats",
    "targetPage": "/guides/uk-arthritis"
  },
  {
    "keyword": "arthritis support england",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "rheumatology waiting times england",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "physiotherapy self referral england",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "arthritis services england nhs",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "disability benefits england",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "blue badge scheme england",
    "intent": "local",
    "category": "local",
    "cluster": "region:england",
    "targetPage": "/regions/england"
  },
  {
    "keyword": "arthritis support scotland",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "rheumatology waiting times scotland",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "physiotherapy self referral scotland",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "arthritis services scotland nhs",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "disability benefits scotland",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "blue badge scheme scotland",
    "intent": "local",
    "category": "local",
    "cluster": "region:scotland",
    "targetPage": "/regions/scotland"
  },
  {
    "keyword": "arthritis support wales",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "rheumatology waiting times wales",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "physiotherapy self referral wales",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "arthritis services wales nhs",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "disability benefits wales",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "blue badge scheme wales",
    "intent": "local",
    "category": "local",
    "cluster": "region:wales",
    "targetPage": "/regions/wales"
  },
  {
    "keyword": "arthritis support northern ireland",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "rheumatology waiting times northern ireland",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "physiotherapy self referral northern ireland",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "arthritis services northern ireland nhs",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "disability benefits northern ireland",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "blue badge scheme northern ireland",
    "intent": "local",
    "category": "local",
    "cluster": "region:northern ireland",
    "targetPage": "/regions/northern-ireland"
  },
  {
    "keyword": "osteoarthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "rheumatoid arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "psoriatic arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "gout help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "ankylosing spondylitis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "fibromyalgia help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "lupus help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "juvenile arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "reactive arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "polymyalgia rheumatica help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "knee arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "hip arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "hand arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "shoulder arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "elbow arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "spinal arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "thumb arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "wrist arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "ankle arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "foot arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "neck arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "facet joint arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "cervical arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "inflammatory arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "degenerative arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "seronegative arthritis help in london",
    "intent": "local",
    "category": "local",
    "cluster": "local:london",
    "targetPage": "/arthritis-support/london"
  },
  {
    "keyword": "osteoarthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "rheumatoid arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "psoriatic arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "gout help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "ankylosing spondylitis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "fibromyalgia help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "lupus help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "juvenile arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "reactive arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "polymyalgia rheumatica help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "knee arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "hip arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "hand arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "shoulder arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  },
  {
    "keyword": "elbow arthritis help in manchester",
    "intent": "local",
    "category": "local",
    "cluster": "local:manchester",
    "targetPage": "/arthritis-support/manchester"
  }
];

export default GENERATED_KEYWORDS;
