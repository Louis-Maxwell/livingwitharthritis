// Post-build: emit per-route static HTML with the correct
// <link rel="canonical"> and <meta property="og:url"> so non-JS
// crawlers (Semrush, Bing, social previewers) see each sitemap URL
// as canonical to itself, not to the homepage.
//
// AI-VISIBILITY UPGRADE: for routes listed in scripts/ai-head-data.json,
// this script also rewrites the static <title>, meta description and
// og/twitter title+description, and injects per-route JSON-LD
// (MedicalWebPage/Article + BreadcrumbList + FAQPage) directly into the
// static HTML. This matters because most AI crawlers (GPTBot,
// OAI-SearchBot, ClaudeBot, PerplexityBot, Google-Extended, CCBot) do
// NOT execute JavaScript — react-helmet-async structured data is
// invisible to them. Baking it into the build output makes every key
// page fully legible and citable to answer engines with zero runtime cost.
//
// Reads routes from public/sitemap.xml (covers every page in the
// sitemap) plus the curated PRERENDER_ROUTES list as a fallback.
// Copies dist/index.html into dist/<route>/index.html with the head
// rewritten. Skips routes whose index.html already exists (so the
// puppeteer prerender `build:prerender` path keeps working).

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { resolve, join, dirname } from "node:path";
import { PRERENDER_ROUTES } from "./prerender-routes.mjs";

const BASE = "https://livingwitharthritis.org.uk";
const DIST = resolve("dist");
const SRC = join(DIST, "index.html");
const AI_DATA_PATH = resolve("scripts/ai-head-data.json");

if (!existsSync(SRC)) {
  console.warn("[inject-canonicals] dist/index.html missing — skipping");
  process.exit(0);
}

const template = readFileSync(SRC, "utf8");

const AI_DATA = existsSync(AI_DATA_PATH)
  ? JSON.parse(readFileSync(AI_DATA_PATH, "utf8"))
  : {};

function collectRoutes() {
  const set = new Set(PRERENDER_ROUTES);
  const sitemapPath = resolve("public/sitemap.xml");
  if (existsSync(sitemapPath)) {
    const xml = readFileSync(sitemapPath, "utf8");
    for (const m of xml.matchAll(/<loc>([^<]+)<\/loc>/g)) {
      const u = m[1].trim();
      const path = u.replace(/^https?:\/\/[^/]+/, "") || "/";
      set.add(path);
    }
  }
  set.delete("/");
  return [...set].filter((p) => p.startsWith("/") && !p.includes("*"));
}

// ---------- AI head enrichment helpers ----------

function escAttr(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escText(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// JSON.stringify drops undefined object properties automatically, but we
// also strip empty arrays for cleanliness.
function compact(obj) {
  return JSON.parse(
    JSON.stringify(obj, (_k, v) => (Array.isArray(v) && v.length === 0 ? undefined : v)),
  );
}

function buildJsonLd(route, url, d) {
  const graphs = [];

  // 1) MedicalWebPage — the page entity itself, tied to the sitewide
  //    Organization/WebSite nodes already present in the static head.
  graphs.push({
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    "@id": `${url}#webpage`,
    url,
    name: d.title,
    headline: d.question || d.title,
    description: d.description,
    inLanguage: "en-GB",
    isPartOf: { "@id": `${BASE}/#website` },
    about: d.about ? { "@type": "MedicalCondition", name: d.about } : undefined,
    lastReviewed: d.updatedAt,
    dateModified: d.updatedAt,
    reviewedBy: {
      "@type": "Organization",
      name: "Living With Arthritis UK clinical team",
      parentOrganization: { "@id": `${BASE}/#organization` },
    },
    publisher: { "@id": `${BASE}/#organization` },
    audience: { "@type": "MedicalAudience", audienceType: "Patient", geographicArea: { "@type": "Country", name: "United Kingdom" } },
    speakable: d.answer
      ? { "@type": "SpeakableSpecification", cssSelector: ["h1", ".answer-box"] }
      : undefined,
  });

  // 2) BreadcrumbList — Home → current page (always-valid two-level trail).
  graphs.push({
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "@id": `${url}#breadcrumb`,
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: `${BASE}/` },
      { "@type": "ListItem", position: 2, name: d.breadcrumb || d.about || d.title, item: url },
    ],
  });

  // 3) FAQPage — the primary Q&A plus any configured FAQs. This is the
  //    highest-value block for answer engines: it hands them a quotable,
  //    attributed question/answer pair per page.
  const qaPairs = [];
  if (d.question && d.answer) qaPairs.push({ q: d.question, a: d.answer });
  if (Array.isArray(d.faqs)) qaPairs.push(...d.faqs);
  if (qaPairs.length > 0) {
    graphs.push({
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "@id": `${url}#faq`,
      mainEntity: qaPairs.map((f) => ({
        "@type": "Question",
        name: f.q,
        acceptedAnswer: { "@type": "Answer", text: f.a },
      })),
    });
  }

  return graphs
    .map(
      (g) =>
        `  <script type="application/ld+json">${JSON.stringify(compact(g))}</script>`,
    )
    .join("\n");
}

function enrichHead(html, route, url) {
  const d = AI_DATA[route];
  if (!d) return html;

  let out = html;

  if (d.title) {
    out = out.replace(/<title>[^<]*<\/title>/i, `<title>${escText(d.title)}</title>`);
    out = out.replace(
      /<meta\s+property="og:title"\s+content="[^"]*"\s*\/?>/i,
      `<meta property="og:title" content="${escAttr(d.title)}" />`,
    );
    out = out.replace(
      /<meta\s+name="twitter:title"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="twitter:title" content="${escAttr(d.title)}" />`,
    );
  }

  if (d.description) {
    out = out.replace(
      /<meta\s+name="description"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="description" content="${escAttr(d.description)}" />`,
    );
    out = out.replace(
      /<meta\s+property="og:description"\s+content="[^"]*"\s*\/?>/i,
      `<meta property="og:description" content="${escAttr(d.description)}" />`,
    );
    out = out.replace(
      /<meta\s+name="twitter:description"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="twitter:description" content="${escAttr(d.description)}" />`,
    );
  }

  // Per-route OG image (build-time satori output) when it exists.
  if (d.ogImage) {
    out = out.replace(
      /<meta\s+property="og:image"\s+content="[^"]*"\s*\/?>/i,
      `<meta property="og:image" content="${escAttr(d.ogImage)}" />`,
    );
    out = out.replace(
      /<meta\s+name="twitter:image"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="twitter:image" content="${escAttr(d.ogImage)}" />`,
    );
  }

  // Inject per-route JSON-LD just before </head>, after the sitewide
  // Organization/WebSite blocks (which stay untouched).
  out = out.replace(/<\/head>/i, `${buildJsonLd(route, url, d)}\n</head>`);

  return out;
}

// ---------- head rewrite (canonical/og:url — unchanged behaviour) ----------

function rewriteHead(html, route) {
  const url = `${BASE}${route}`;
  // Replace homepage og:url with route-specific og:url.
  let out = html.replace(
    /<meta\s+property="og:url"\s+content="[^"]*"\s*\/?>/i,
    `<meta property="og:url" content="${url}" />`,
  );
  // Replace homepage canonical with route-specific canonical.
  if (/<link\s+rel="canonical"[^>]*>/i.test(out)) {
    out = out.replace(
      /<link\s+rel="canonical"\s+href="[^"]*"\s*\/?>/i,
      `<link rel="canonical" href="${url}" />`,
    );
  } else {
    out = out.replace(/<\/head>/i, `  <link rel="canonical" href="${url}" />\n</head>`);
  }
  // Also update twitter:url if present.
  out = out.replace(
    /<meta\s+name="twitter:url"\s+content="[^"]*"\s*\/?>/i,
    `<meta name="twitter:url" content="${url}" />`,
  );
  // AI-visibility enrichment (title, description, JSON-LD) for curated routes.
  out = enrichHead(out, route, url);
  return out;
}

const routes = collectRoutes();
let written = 0;
let skipped = 0;
let enriched = 0;

for (const route of routes) {
  const dir = join(DIST, route.replace(/^\//, ""));
  const file = join(dir, "index.html");
  if (existsSync(file)) {
    skipped++;
    continue;
  }
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, rewriteHead(template, route));
  written++;
  if (AI_DATA[route]) enriched++;
}

console.log(
  `[inject-canonicals] wrote ${written} per-route HTML files (skipped ${skipped} existing, ${enriched} AI-enriched with static JSON-LD)`,
);
